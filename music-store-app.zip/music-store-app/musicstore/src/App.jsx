
//import './App.css'
import { SearchPage } from './pages/SearchPage'

function App() {

  return (
    <>  <SearchPage/>
    </>
  )
}

export default App
